package com.example.todolist.model

data class Todo(
    val title : String,
    val isChecked :Boolean
)